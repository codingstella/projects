VanillaTilt.init(document.querySelector(".container"), {
  max: 15,
  speed: 400,
  glare: true,
  "max-glare": 0.2
});

// Built this calculator following this guide: https://www.youtube.com/watch?v=NhcZh8Bwr30&t=5s